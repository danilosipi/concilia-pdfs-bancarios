# concilia_pdfs/__main__.py
import argparse
import logging
from pathlib import Path
import sys
import os
import getpass

# Add the project root to the Python path to allow absolute imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from concilia_pdfs.parsers.btg_parser import parse_btg_pdf
from concilia_pdfs.parsers.organize_parser import parse_organize_pdf
from concilia_pdfs.core.reconciliation import reconcile_transactions
from concilia_pdfs.reporting.excel_writer import generate_excel_report

def _resolve_pdf_password(args) -> str | None:
    """
    Resolve senha do PDF seguindo prioridade:
    1) CLI --pdf_password
    2) ENV CONCILIA_PDF_PASSWORD
    3) Prompt seguro no terminal (getpass), se necessário
    """
    if args.pdf_password:
        return args.pdf_password

    env_pwd = os.getenv("CONCILIA_PDF_PASSWORD")
    if env_pwd:
        return env_pwd

    # Se chegou aqui, ainda não temos senha. Pergunta ao usuário (sem ecoar no terminal).
    try:
        pwd = getpass.getpass("PDF protegido. Digite a senha (ENTER para tentar sem senha): ")
        pwd = pwd.strip()
        return pwd if pwd else None
    except Exception:
        # Se não conseguir ler do terminal, volta None
        return None

def main():
    """Função principal para executar a reconciliação de PDFs via CLI."""
    parser = argparse.ArgumentParser(
        description="Reconcilia extratos de cartão de crédito em PDF do BTG e do Organize."
    )

    parser.add_argument(
        "--pdf_password",
        type=str,
        default=None,
        help="Senha para PDFs protegidos (se não informar, tenta ENV ou pede no terminal)."
    )

    parser.add_argument(
        "--btg",
        type=str,
        required=True,
        help="Caminho para o extrato em PDF do BTG."
    )
    parser.add_argument(
        "--organize_dir",
        type=str,
        required=True,
        help="Diretório contendo os extratos em PDF do Organize."
    )
    parser.add_argument(
        "--out",
        type=str,
        required=True,
        help="Diretório de saída para os relatórios Excel."
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Ativa o logging de depuração."
    )
    args = parser.parse_args()

    # Configure logging
    log_level = logging.DEBUG if args.debug else logging.INFO
    logging.basicConfig(level=log_level, format='%(asctime)s - %(levelname)s - %(message)s')

    logging.info("--- Iniciando Processo de Reconciliação de PDFs ---")

    pdf_password = _resolve_pdf_password(args)

    # 1. Parse all BTG transactions
    btg_file = Path(args.btg)
    if not btg_file.is_file():
        logging.error(f"Arquivo BTG não encontrado: {btg_file}")
        return

    try:
        all_btg_txs = list(parse_btg_pdf(str(btg_file), pdf_password=pdf_password))
    except Exception as e:
        logging.error(
            f"Falha ao abrir/analisar o PDF do BTG. arquivo={btg_file} erro_tipo={type(e).__name__} erro={repr(e)}"
        )
        logging.error("Dica: informe --pdf_password, ou defina ENV CONCILIA_PDF_PASSWORD, ou rode em modo interativo.")
        return

    logging.info(f"Encontradas {len(all_btg_txs)} transações no total no PDF do BTG.")

    # 2. Parse all Organize transactions
    organize_dir = Path(args.organize_dir)
    if not organize_dir.is_dir():
        logging.error(f"Diretório do Organize não encontrado: {organize_dir}")
        return

    all_organize_txs = []
    org_files = list(organize_dir.glob("*.pdf"))

    if not org_files:
        logging.warning(f"Nenhum PDF do Organize encontrado em: {organize_dir}")

    for org_file in org_files:
        try:
            all_organize_txs.extend(list(parse_organize_pdf(str(org_file), pdf_password=pdf_password)))
        except Exception as e:
            logging.error(
                f"Falha ao abrir/analisar PDF do Organize. arquivo={org_file} erro_tipo={type(e).__name__} erro={repr(e)} | Continuando..."
            )
            continue

    logging.info(f"Encontradas {len(all_organize_txs)} transações no total em {len(org_files)} PDFs do Organize.")

    # 3. Reconcile transactions
    reconciliation_results = reconcile_transactions(all_btg_txs, all_organize_txs)

    # 4. Generate reports
    generate_excel_report(reconciliation_results, all_btg_txs, all_organize_txs, args.out)

    logging.info("--- Processo de Reconciliação de PDFs Finalizado com Sucesso ---")

if __name__ == "__main__":
    main()
